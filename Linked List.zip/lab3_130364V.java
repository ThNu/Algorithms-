
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import static jdk.nashorn.internal.objects.NativeString.toUpperCase;

public class lab3_130364V {

    public static void main(String[] args) {
        CS2022LinkedList<String> list = new CS2022LinkedList<String>();
        list.init_list();
        lab3_130364V lab3 = new lab3_130364V();
        FileOutputStream out = null;
        try {
            out = new FileOutputStream("E:\\Javaexamples\\data structures and algorithms\\LinkedList\\src\\result.out");
            PrintStream output = new PrintStream(out);
            FileReader in = new FileReader(args[0]);
            BufferedReader line = new BufferedReader(in);
            String str;
            str = line.readLine();
            while (str != null && str.length() != 0) {
                if (str.equals("ISEMPTY")) {
                    System.out.println(toUpperCase(list.is_empty()));
                    output.println(toUpperCase(list.is_empty()));
                } else if (str.equals("GETLENGTH")) {
                    System.out.println(list.getLength());
                    output.println(Integer.toString(list.getLength()));
                } else {
                    String[] x = str.split(" ");
                    if (x[0].equals("INSERT")) {
                        if (x[1].charAt(0) == '\"') {
                            list.insert(x[1].substring(1, -1));
                        } else {
                            list.insert(x[1]);
                        }
                    } else if (x[0].equals("INSERTAT")) {
                        if (x[1].charAt(0) == '\"') {
                            list.insertAt(x[1].substring(1, x[1].length() - 1), Integer.parseInt(x[2]));
                        } else {
                            list.insertAt(x[1], Integer.parseInt(x[2]));
                        }
                    } else if (x[0].equals("DELETE")) {
                        if (x[1].charAt(0) == '\"') {
                            list.delete(x[1].substring(1, -1));
                        } else {
                            list.delete(x[1]);
                        }
                    } else if (x[0].equals("DELETEAT")) {
                        list.deleteNodeAt(Integer.parseInt(x[1]));
                    } else if (x[0].equals("SEARCH")) {
                        if (x[1].charAt(0) == '\"') {
                            if (list.search(x[1].substring(1, -1)) == null) {
                                System.out.println("FALSE");
                                output.println("FALSE");
                            } else {
                                System.out.println("TRUE");
                                output.println("TRUE");
                            }
                        } else {
                            if (list.search(x[1]) == null) {
                                System.out.println("FALSE");
                                output.println("FALSE");
                            } else {
                                System.out.println("TRUE");
                                output.println("TRUE");
                            }
                        }
                    }

                }
                str = line.readLine();
            }
            out.close();
            line.close();
        } catch (IOException ex) {
            Logger.getLogger(lab3_130364V.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

class Node<E> {

    private E element;
    private Node<E> next;

    public void setElement(E element) {
        this.element = element;
    }

    public E getElement() {
        return element;
    }

    public void setNext(Node<E> next) {
        this.next = next;
    }

    public Node<E> getNext() {
        return next;
    }
}

class CS2022LinkedList<E> {

    private Node<E> head;
    private int length;

    public void init_list() {
        Node<E> list = new Node<E>();
        list.setElement(null);
        list.setNext(null);
        setHead(list);
        length = 0;
    }

    public boolean is_empty() {
        if (head.getElement() == null) {
            return true;
        } else {
            return false;
        }
    }

    public Node<E> search(E element) {
        if (head.getElement().equals(element)) {
            return head;
        }
        Node<E> newNode = new Node<E>();
        newNode = getHead();
        for (int i = 1; i < getLength() ; i++) {
            newNode = newNode.getNext();
            if (newNode.getElement().equals(element)) {
                return newNode;
            }
        }
        return null;
    }

    public E delete(E element) {
        if (head.getElement() == null) {
            return null;
        } else if (head.getElement().equals(element)) {
            head = head.getNext();
            decrementLength();
            return element;
        } else {
            Node<E> newNode = new Node<E>();
            newNode = getHead();
            for (int i = 1; i < getLength(); i++) {
                if (newNode.getNext().getElement().equals(element)) {
                    newNode.setNext(newNode.getNext().getNext());
                    decrementLength();
                    return element;
                }
                newNode = newNode.getNext();
            }
            return null;
        }
    }

    public E deleteNodeAt(int i) {
        if (getLength() < i || i <= 0) {
            return null;
        } else if (i == 1) {
            E element = head.getElement();
            head = head.getNext();
            decrementLength();
            return element;
        } else {
            E element;
            Node<E> newNode = new Node<E>();
            newNode = getHead();
            for (int j = 1; j < i - 1; j++) {
                newNode = newNode.getNext();
            }
            element = newNode.getNext().getElement();
            newNode.setNext(newNode.getNext().getNext());
            decrementLength();
            return element;
        }

    }

    public boolean insert(E element) {
        Node<E> n = new Node<E>();
        n.setElement(null);
        n.setNext(null);
        if (head.getElement() == null) {
            head.setElement(element);
            head.setNext(n);
            incrementLength();
            return true;
        } else if (head.getElement() != null) {
            n.setElement(element);
            Node<E> newNode = new Node<E>();
            newNode = getHead();
            for (int i = 1; i < getLength(); i++) {
                newNode = newNode.getNext();
            }
            newNode.setNext(n);
            incrementLength();
            return true;
        } else {
            return false;
        }
    }

    public boolean insertAt(E element, int i) {
        if (i > getLength()) {
            return false;
        }
        else if(i==1){
            Node<E> n = new Node<E>();
            n.setElement(element);
            n.setNext(getHead());
            setHead(n);
            incrementLength();
            return true;
        }
        else {
            Node<E> n = new Node<E>();
            n.setElement(element);
            Node<E> newNode1 = new Node<E>();
            Node<E> newNode2 = new Node<E>();
            newNode1 = getHead();
            for (int j = 1; j < i - 1; j++) {
                newNode1 = newNode1.getNext();
            }
            newNode2 = newNode1.getNext();
            n.setNext(newNode2);
            newNode1.setNext(n);
            incrementLength();
            return true;
        }
    }

    public void setHead(Node<E> head) {
        this.head = head;
    }

    public Node<E> getHead() {
        return head;
    }

    public void incrementLength() {
        this.length++;
    }

    public void decrementLength() {
        this.length--;
    }

    public int getLength() {
        return length;
    }
}
