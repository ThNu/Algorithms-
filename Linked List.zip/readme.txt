130364V
T.N.Malawaraarachchi
ENTC

1.Open command prompt and go to the unzipped folder 130364V
2.Type following lines in the command prompt
		javac lab3_130364V.java
		java lab3_130364V input.txt 