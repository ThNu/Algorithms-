
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

class Heap {

    public int[] heap;
    public int heapSize;
    public final int length;

    public Heap(int length) {
        this.length = length;
        heap = new int[length];
        heapSize = 0;
    }

    int Parent(int i) {
        return i / 2;
    }

    int Left(int i) {
        return 2 * i;
    }

    int Right(int i) {
        return 2 * i + 1;
    }

    void Max_Heapify(Heap heap, int i) {
        int left = Left(i);
        int right = Right(i);
        int largest;
        if (left <= heap.heapSize && heap.heap[left - 1] > heap.heap[i - 1]) {
            largest = left;
        } else {
            largest = i;
        }
        if (right <= heap.heapSize && heap.heap[right - 1] > heap.heap[largest - 1]) {
            largest = right;
        }
        if (largest != i) {
            int temp = heap.heap[i - 1];
            heap.heap[i - 1] = heap.heap[largest - 1];
            heap.heap[largest - 1] = temp;
            Max_Heapify(heap, largest);
        }
    }

    void BuildMax_Heapify(Heap heap) {
        for (int i = heap.heapSize / 2; i > 0; i--) {
            Max_Heapify(heap, i);
        }
    }

    int HeapMaximum(Heap heap) {
        return heap.heap[0];
    }

    int HeapExtractMaximum(Heap heap) {
        int max = heap.heap[0];
        for (int i = 0; i < heap.heapSize; i++) {
            heap.heap[i] = heap.heap[i + 1];
        }
        BuildMax_Heapify(heap);
        return max;
    }

    int Max_HeapInsert(Heap heap, int element) {
        heap.heap[heap.heapSize] = element;
        heap.heapSize++;
        int val = heap.heap[heap.heapSize - 1];
        BuildMax_Heapify(heap);
        return val;
    }

    int HeapIncreaseKey(Heap heap, int i, int amount) {
        heap.heap[i] += amount;
        return heap.heap[i];
    }

    void HeapSort(Heap heap) {
        BuildMax_Heapify(heap);
        int size = 0;
        for (int i = heap.heapSize; i > 0; i--) {
            int temp = heap.heap[0];
            heap.heap[0] = heap.heap[i - 1];
            heap.heap[i - 1] = temp;
            heap.heapSize--;
            size++;
            heap.Max_Heapify(heap, 1);
        }
        heap.heapSize = size;
    }
}

public class Lab6_130364V {

    public static void main(String[] args) {
        try {
            String fileName = args[0];
            File file = new File(fileName);
            Scanner input = new Scanner(file);
            FileWriter fileWriter = new FileWriter("output.txt");
            String output = "";
            String inputValues = input.nextLine();
            String[] values = inputValues.split(",");
            Heap heap = new Heap(15);
            for (int i = 0; i < values.length; i++) {
                heap.Max_HeapInsert(heap, Integer.valueOf(values[i]));
            }
            heap.HeapSort(heap);
            for (int i = 0; i < heap.heapSize; i++) {
                if (i != heap.heapSize - 1) {
                    output += String.valueOf(heap.heap[i]) + ", ";
                } else {
                    output += String.valueOf(heap.heap[i]);
                }
            }
            fileWriter.write(output);
            fileWriter.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Lab6_130364V.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Lab6_130364V.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
