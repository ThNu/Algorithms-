T.N.Malawaraarachchi
130364V

type following commands in the command prompt after going to the correct location file
		javac Lab6_130364V.java
		java Lab6_130364V input.txt