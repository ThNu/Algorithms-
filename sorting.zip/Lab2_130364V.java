import java.io.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Lab2_130364V{
   
    public static void main(String[] args) {
        //Task 1
        
        // merge sort with read input through a text file.
        
        Lab2_130364V lab2 = new Lab2_130364V();
        try {
            int[] A = lab2.Read_Input(args[0]);
            int[] sortedArray = lab2.Merge_Sort(A,0,(A.length-1));
            lab2.Print_Output(sortedArray);
            lab2.Write_Output(sortedArray);
        } catch (IOException ex) {
            Logger.getLogger(Lab2_130364V.class.getName()).log(Level.SEVERE, null, ex);
        }     
        
        //Task 2
        
//        Random rnd=new Random();
//        int[] X=new int[1000];
//        for(int i=0;i<X.length;i++){
//            X[i]=rnd.nextInt();
//        }
        
        //time analysis for merge sort
        
//        Lab2_130364V lab2=new Lab2_130364V();
//        long begin = System.currentTimeMillis();
//        lab2.Merge_Sort(X, 0, X.length-1);
//        long end = System.currentTimeMillis();
//        System.out.println(end-begin);    
        
        //time analysis for insertion sort
        
//        Lab2_130364V lab2=new Lab2_130364V();
//        long begin = System.currentTimeMillis();
//        int n=X.length;
//        lab2.insertion_sort(n, X);
//        long end = System.currentTimeMillis();
//        System.out.println(end-begin);
    }
    
    void Print_Output(int X[]){
        for(int i=0;i<X.length;i++){
                System.out.print(X[i]);
                if(i!=X.length-1){
                    System.out.print(",");
                }
            }
    }
    
    void insertion_sort(int n,int A[]){
            int key,i;
            for(int j=1;j<n;j++){
                key = A[j];
                i=j-1;
                while(i>=0 && A[i]>key){
                    A[i+1]=A[i];
                    i=i-1;               
                }
                A[i+1]=key;
            }
            
            	
	}
    
    int [] Merge_Sort(int A[], int p, int r){
        int q;
        if(p<r){
            q=((p+r)/2);
            Merge_Sort(A,p,q);
            Merge_Sort(A,q+1,r);
            Merge(A,p,q,r);
        }
        return A; 
    }
    static void Merge(int A[], int p, int q, int r){
        int n1=q-p+1;
        int n2=r-q;
        int[] L=new int[n1+1];
        int[] R=new int[n2+1];
        for(int i=0;i<n1;i++){
            L[i]=A[p+i];
        }
        for(int j=0;j<n2;j++){
            R[j]=A[q+j+1];
        }
        L[n1]=Integer.MAX_VALUE;
        R[n2]=Integer.MAX_VALUE;
        int i=0;
        int j=0;
        for(int k=p;k<r+1;k++){
            if(L[i]<=R[j]){
                A[k]=L[i];
                i=i+1;
            }
            else{
                A[k]=R[j];
                j=j+1;
            }
        }
    }
    
    int [] Read_Input(String fileName) throws IOException{
        FileReader in = new FileReader(fileName);
        BufferedReader line = new BufferedReader(in);
        String[] s = new String[2];
        for(int i=0;i<2;i++){
            s[i]=line.readLine();
        }
        line.close();
        String[] a = s[1].split(",");
        int[] A=new int[a.length];
        for(int i=0;i<a.length;i++){
            A[i]=Integer.parseInt(a[i]);
        }       
        return A;
    }
    
    void Write_Output(int[] sortedArray) throws IOException{
        FileOutputStream out=null;
        try{
            out=new FileOutputStream("E:\\Javaexamples\\netbeansexercises\\oopexercises\\merge_sort\\src\\result.out");
            PrintStream output = new PrintStream(out);
            for(int i=0;i<sortedArray.length;i++){
                output.print(sortedArray[i]);
                if(i!=sortedArray.length-1){
                    output.print(',');
                }
            }
        }
        catch(IOException ex){
            Logger.getLogger(Lab2_130364V.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            if(out!=null){
                out.close();
            }
        }
    }   
}
