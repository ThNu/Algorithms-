T.N.Malawaraarachchi
130364V

line 9,11,23,31 and 39 are all commments.

Task 1:
	in the main method
	i).comment line 25 to 46.
	ii).uncomment line 13 to 21 and run the file

Task 2:
	@uncomment line 25 to 29.

	estimating time for merge sort:
		i).comment line 13 to 21.
		ii).comment line 41 to 46.
		iii).uncomment line 33 to 37 and run the file
	
	estimating time for insertion sort:
		i).comment line 13 to 21.
		ii).comment line 33 to 37.
		iii).uncomment line 41 to 46 and run the file
			