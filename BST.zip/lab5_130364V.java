
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class lab5_130364V {

    public static void main(String[] args) throws IOException {
//        BintreeNode tree = new BintreeNode();
//        int[] elements = {1, 2, 3, 4, 5, 5};
//        tree.createTree(elements);
//        int[] ele = {6, 6, 7, 8, 8, 8};
//        tree.expandTree(tree, ele);
//
//        tree.traverse_inorder(tree);
//        System.out.println("");
//        tree.traverse_preorder(tree);
//        System.out.println("");
//        tree.traverse_postorder(tree);

//        BSTNode bst = new BSTNode(6);
//        bst.addValue(bst, 4);
//        bst.addValue(bst, 7);
//        bst.addValue(bst, 10);
//        bst.addValue(bst, 1);
//        bst.addValue(bst, 14);
////        bst.addValue(bst, 8);
//        // bst.traverse_inorder(bst);
//        // bst.traverse_preorder(bst);
//        // bst.traverse_postorder(bst);
//
//        Boolean k = bst.deleteValue(bst, 1);
//        System.out.println(k);
//        bst.print_tree(bst);
        FileReader in = new FileReader(args[0]);
        BufferedReader inLine = new BufferedReader(in);
        FileWriter out = new FileWriter("result.out");
        BintreeNode.output = "";
        BSTNode root = null;
        while (true) {
            String line = inLine.readLine();
            if (line == null) {
                break;
            }

            String[] operation = line.split(" ");
            if (operation[0].equals("create")) {
                root = new BSTNode(Integer.parseInt(operation[1]));

                for (int i = 2; i < operation.length; i++) {
                    root.addValue(root, Integer.parseInt(operation[i]));
                }
                BintreeNode.output += "S" + "\n";

            } else if (operation[0].equals("print")) {
                root.print_tree(root);

                BintreeNode.output += BintreeNode.temp_output + "\n";
                BintreeNode.temp_output = "";
            } else if (operation[0].equals("search")) {
                BintreeNode y = root.searchValue(root, Integer.parseInt(operation[1]));
                if (y == null) {

                    BintreeNode.output += "F" + "\n";
                } else {

                    BintreeNode.output += "T" + "\n";
                }

            } else if (operation[0].equals("delete")) {
                boolean del = root.deleteValue(root, Integer.parseInt(operation[1]));
                if (del) {

                    BintreeNode.output += "S" + '\n';
                } else {

                    BintreeNode.output += "F" + "\n";
                }

            } else if (operation[0].equals("add")) {
                boolean add = root.addValue(root, Integer.parseInt(operation[1]));
                if (add) {

                    BintreeNode.output += "S" + "\n";
                } else {

                    BintreeNode.output += "F" + "\n";
                }
            } else if (operation[0].equals("pre-order")) {
                root.traverse_preorder(root);

                BintreeNode.output += BintreeNode.temp_output + "\n";
                BintreeNode.temp_output = "";
            } else if (operation[0].equals("in-order")) {
                root.print_tree(root);

                BintreeNode.output += BintreeNode.temp_output + "\n";
                BintreeNode.temp_output = "";
            } else if (operation[0].equals("post-order")) {
                root.traverse_postorder(root);

                BintreeNode.output += BintreeNode.temp_output + "\n";
                BintreeNode.temp_output = "";
            } else {
                System.out.println("Invalid command");
            }
        }
        out.write(BintreeNode.output);
        out.close();
        System.out.println(BintreeNode.output);

    }

}

class BintreeNode {

    static String temp_output = "";
    static String output = "";
    int value;
    BintreeNode left;
    BintreeNode right;

    public BintreeNode() {
        left = null;
        right = null;
    }

    boolean addLeftChild(BintreeNode parent, int newvalue) {
        if (parent.left != null) {
            return false;
        } else {
            BintreeNode newNode = new BintreeNode();
            newNode.value = newvalue;
            parent.left = newNode;
            return true;
        }
    }

    boolean addRightChild(BintreeNode parent, int newvalue) {
        if (parent.right != null) {
            return false;
        } else {
            BintreeNode newNode = new BintreeNode();
            newNode.value = newvalue;
            parent.right = newNode;
            return true;
        }
    }

    BintreeNode createTree(int[] elements) {
        this.value = elements[0];
        ArrayList<BintreeNode> parentList = new ArrayList<BintreeNode>();
        parentList.add(this);
        ArrayList<BintreeNode> tempList;
        int i = 1;
        while (i < elements.length) {
            tempList = new ArrayList<BintreeNode>();
            for (BintreeNode node : parentList) {
                addLeftChild(node, elements[i]);
                i++;
                if (i >= elements.length) {
                    break;
                }
                addRightChild(node, elements[i]);
                i++;
                tempList.add(node.left);
                tempList.add(node.right);
            }
            parentList = tempList;
        }
        return this;
    }

    boolean expandTree(BintreeNode root, int[] elements) {
        ArrayList<BintreeNode> list = new ArrayList<BintreeNode>();
        list.add(root);
        ArrayList<BintreeNode> parentList = new ArrayList<BintreeNode>();
        parentList = getEnd(list);
        ArrayList<BintreeNode> tempList;
        int j = 0;
        while (j < elements.length) {
            tempList = new ArrayList<BintreeNode>();
            for (BintreeNode node : parentList) {
                if (j >= elements.length) {
                    break;
                }
                if (node.left == null) {
                    addLeftChild(node, elements[j]);
                    j++;
                }
                if (j >= elements.length) {
                    break;
                }
                if (node.right == null) {
                    addRightChild(node, elements[j]);
                    j++;
                }
                tempList.add(node.left);
                tempList.add(node.right);
            }
            parentList = tempList;
        }
        return true;
    }

    ArrayList<BintreeNode> getEnd(ArrayList<BintreeNode> root) {
        ArrayList<BintreeNode> temp1 = new ArrayList<BintreeNode>();
        temp1 = root;
        BintreeNode temp = new BintreeNode();
        while (true) {
            for (int i = 0; i < temp1.size(); i++) {
                temp = temp1.get(i);
                if (temp.left == null) {
                    return temp1;
                }
                if (temp.right == null) {
                    return temp1;
                }
                root.add(temp.left);
                root.add(temp.right);
            }
            temp1 = root;
        }
    }

    void traverse_inorder(BintreeNode root) {
        if (root != null) {
            traverse_inorder(root.left);
            temp_output += "" + root.value + " ";
            traverse_inorder(root.right);
        }
    }

    void traverse_preorder(BintreeNode root) {
        if (root != null) {
            temp_output += "" + root.value + " ";
            traverse_preorder(root.left);
            traverse_preorder(root.right);
        }
    }

    void traverse_postorder(BintreeNode root) {
        if (root != null) {
            traverse_postorder(root.left);
            traverse_postorder(root.right);
            temp_output += "" + root.value + " ";
        }
    }
}

class BSTNode extends BintreeNode {

    BSTNode(int newvalue) {
        this.value = newvalue;
    }

    boolean addValue(BSTNode root, int newvalue) {
        if (root != null) {
            BintreeNode rt = findCorrectPosition(root, newvalue);
            if (newvalue <= rt.value) {
                addLeftChild(rt, newvalue);
            }
            if (newvalue > rt.value) {
                addRightChild(rt, newvalue);
            }
            return true;
        }
        return false;
    }

    BintreeNode findCorrectPosition(BSTNode root, int newvalue) {
        BintreeNode y = root;
        while (true) {
            if (newvalue <= y.value) {
                if (y.left == null) {
                    return y;
                }
                y = y.left;
            }
            if (newvalue > y.value) {
                if (y.right == null) {
                    return y;
                }
                y = y.right;
            }

        }
    }

    boolean deleteValue(BSTNode root, int value) {
        BintreeNode x = searchValue(root, value);
        if (x == null) {
            return false;
        } else if (x.left == null) {
            if (x.right == null) {
                x = null;
            } else {
                while (x.right != null) {
                    x.value = x.right.value;

                    if (x.right.right == null) {
                        x.right = null;
                    }

                }
            }

        } else if (x.right == null) {
            if (x.left == null) {
                x = null;
            } else {
                while (x.left != null) {
                    x.value = x.left.value;
                    if (x.left.left == null) {
                        x.left = null;
                    }
                }
            }

        } else {
            BintreeNode next = x.right;
            while (true) {
                if (next.left == null) {
                    break;
                } else {
                    next = next.left;
                }
            }
            x.value = next.value;
            if (x.right.equals(next)) {
                x.right = next.right;
            }

            next = next.right;
        }
        return true;
    }

    BintreeNode searchValue(BintreeNode root, int value) {
        while (true) {
            if (root == null) {
                return null;
            }
            if (root.value == value) {
                return root;
            }
            if (value < root.value) {
                root = root.left;
            } else {
                root = root.right;
            }
        }
    }

    void print_tree(BSTNode root) {
        traverse_inorder(root);
    }
}
