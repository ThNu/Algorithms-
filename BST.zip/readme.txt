130364V
ENTC
T.N.Malawaraarachchi

To compile the code....
	type "javac lab4_130364V.java" in the command prompt.

To run the file....
	type "java lab4_130364V input.txt" in the command prompt.

Output is written to a file named output.out in the same file where java file is stored.